import ollama
import streamlit as st
from datetime import datetime
import time

# Streamlit UI
st.title("Psychiatrist Chatbot")
st.write("Share your thoughts with the AI psychiatrist. It will analyze your emotions, ask multiple questions, and suggest tasks to support you.")

# User session management
if 'user_id' not in st.session_state:
    st.session_state.user_id = f"User{int(time.time())}"  # Unique user ID based on timestamp
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []
if 'conversation_context' not in st.session_state:
    st.session_state.conversation_context = []  # Store previous inputs for context

# Emotional analysis and interactive response generation with Neural Chat
def analyze_and_respond(chat_text):
    # Define the psychiatrist role and description
    role_description = "You are a compassionate and professional psychiatrist with 10 years of experience. Your role is to analyze the emotional tone of the user's message (happy, sad, neutral, or distress) and provide a therapeutic response tailored to their state, especially if sad or distressed. Use empathetic language and suggest coping strategies. For sad or distressed users, ask 2-3 follow-up questions at a student level (e.g., 'What happened today?', 'How long have you felt this way?') to understand their situation, assign a task to change their mindset (e.g., 'Take a 5-minute walk', 'Write 3 things you’re grateful for'), and introduce an engaging topic (e.g., nature, music) to encourage positive thinking. Use the conversation context to make responses relevant and interactive."

    # Build conversation context
    context = "\n".join([f"User: {msg}" for msg in st.session_state.conversation_context]) if st.session_state.conversation_context else "No previous context."
    messages = [
        {'role': 'system', 'content': role_description},
        {'role': 'user', 'content': f"Conversation context:\n{context}\nAnalyze the following user chat for emotional tone:\nLast Chat: {chat_text}\nDate: {datetime.now()}\nOutput: Is the user happy, sad, neutral, or distress? Suggest a therapeutic response. If sad or distressed, provide 2-3 follow-up questions, a task to change their mindset, and an engaging topic."}
    ]
    
    response = ollama.chat(model='neural-chat', messages=messages)
    content = response['message']['content']
    
    # Parse the response
    lines = content.split('\n')
    tone = lines[0].split(': ')[1]
    response_text = lines[1].split(': ')[1] if len(lines) > 1 else 'No response needed'
    
    if tone in ['sad', 'distress']:
        followup_questions = [lines[i].split(': ')[1] for i in range(2, 5) if i < len(lines) and ': ' in lines[i]][:3]  # Get up to 3 questions
        task = lines[5].split(': ')[1] if len(lines) > 5 and ': ' in lines[5] else "Take a 5-minute walk to clear your mind."
        topic = lines[6].split(': ')[1] if len(lines) > 6 and ': ' in lines[6] else "Let’s discuss how music can lift your mood."
        return tone, response_text, followup_questions, task, topic
    return tone, response_text, None, None, None

# User input and interactive chat
user_input = st.text_area("How are you feeling today?", height=100)
if st.button("Send"):
    if user_input:
        # Add to conversation context
        st.session_state.conversation_context.append(user_input)
        
        # Analyze emotional tone and get response
        emotional_tone, therapeutic_response, followup_questions, task, topic = analyze_and_respond(user_input)
        
        # Display conversation
        st.session_state.chat_history.append({"User": user_input, "Tone": emotional_tone, "Response": therapeutic_response, "Followups": followup_questions, "Task": task, "Topic": topic})
        st.write(f"**You:** {user_input}")
        st.write(f"**Psychiatrist Analysis:** {emotional_tone}")
        if emotional_tone in ['sad', 'neutral', 'distress']:
            st.write(f"**Psychiatrist Response:** {therapeutic_response}")
            if followup_questions:
                st.write("**Follow-up Questions:**")
                for i, question in enumerate(followup_questions, 1):
                    st.write(f"{i}. {question}")
            if task:
                st.write(f"**Task to Change Mindset:** {task}")
            if topic:
                st.write(f"**Engaging Topic:** {topic}")
        elif emotional_tone == 'happy':
            st.write(f"**Psychiatrist Response:** I’m glad to hear you’re doing well! Keep it up!")
    else:
        st.warning("Please enter a message.")

# Display chat history
if st.session_state.chat_history:
    st.subheader("Chat History")
    for entry in st.session_state.chat_history:
        st.write(f"**You:** {entry['User']}")
        st.write(f"**Analysis:** {entry['Tone']}")
        st.write(f"**Response:** {entry['Response'] if entry['Tone'] in ['sad', 'neutral', 'distress'] else 'I’m glad to hear you’re doing well! Keep it up!'}")
        if entry['Followups']:
            st.write("**Follow-up Questions:**")
            for i, question in enumerate(entry['Followups'], 1):
                st.write(f"{i}. {question}")
        if entry['Task']:
            st.write(f"**Task:** {entry['Task']}")
        if entry['Topic']:
            st.write(f"**Engaging Topic:** {entry['Topic']}")
        st.write("---")

# Run the app
if __name__ == "__main__":
    st.write("Start chatting with the psychiatrist AI!")